// import logo from './logo.jpg';
// import klu from './klu.png';
import './App.css';
import Id from './components/Id';
import Calcc from './components/Calcc';
import { BrowserRouter, Routes, Route } from 'react-router-dom'; //npm i react-router-dom to install react-router-dom package in client cmd
//BrowserRouter, Routes and Route are used to route from one page to another like from signup to login etc.
import { Container, Toolbar, AppBar } from '@material-ui/core'; //npm i @material-ui/core --force to install @material-ui/core package in client cmd


function App() {
  // function opetarion(){
  //   let vl=document.getElementById("Value");
  //   vl.value="1";
  // }
  return(
    <div className="App">

      <div className='App-body'>
      <BrowserRouter>
            <Routes>
              <Route path='/' element={<Id />} />
              <Route path='/calc' element={<Calcc />} />
            </Routes>
      </BrowserRouter>
        {/* <div className='App-calc'>
          <div>
            <input id="Value" className='App-inputval' type="text" name='value'/>
          </div>
          <div>
            <button className='App-plus' onSubmit={opetarion}>1</button>
            <button className='App-plus'>2</button>
            <button className='App-plus'>3</button>
            <button className='App-plus'>+</button>
          </div>
          <div>
            <button className='App-plus'>4</button>
            <button className='App-plus'>5</button>
            <button className='App-plus'>6</button>
            <button className='App-plus'>-</button>
          </div>
          <div>
            <button className='App-plus'>7</button>
            <button className='App-plus'>8</button>
            <button className='App-plus'>9</button>
            <button className='App-plus'>/</button>
          </div>
          <div>
            <button className='App-zero'>0</button>
            <button className='App-plus'>*</button>
          </div>
        </div> */}
      </div>
      </div>
      
  );

}

export default App;
