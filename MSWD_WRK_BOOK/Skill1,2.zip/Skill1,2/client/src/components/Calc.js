import '../App.css';
import {useState} from 'react';


function Calc(){
    const [ value, setValue ] = useState("")
    const [ value1, setValue1 ] = useState(0)

	const opetarion1 = () => setValue(value+"1")
    const opetarion2 = () => setValue(value+"2")
    const opetarion3 = () => setValue(value+"3")
    const opetarion4 = () => setValue(value+"4")
    const opetarion5 = () => setValue(value+"5")
    const opetarion6 = () => setValue(value+"6")
    const opetarion7 = () => setValue(value+"7")
    const opetarion8 = () => setValue(value+"8")
    const opetarion9 = () => setValue(value+"9")
    const opetarion0 = () => setValue(value+"0")
    const opetarionAdd = () => setValue(value+"+")
    const opetarionSub = () => setValue(value+"-")
    const opetarionMul = () => setValue(value+"*")
    const opetarionDiv = () => setValue(value+"/")
    const opetarionEql = () => {
        console.log(value);
        let i;
        let j;
        let a="";
        let b="";
        let t=0;

        for(i=0;i<value.length;i++)
        {
            
            if(value[i]=="+")
            {
                for(j=i+1;j<value.length;j++)
                {
                    if(value[j]=="+" || value[j]=="-" || value[j]=="*" || value[j]=="/")
                    {
                        let a1=parseInt(a);
                        let b1=parseInt(b);
                        t=t+(a1+b1);
                        a="";
                        b="";
                        console.log(t);
                        i=j;
                        break;
                    }
                    else{
                        b=b+value[j];
                    }
                }
            }
            else if(value[i]=="-")
            {
                for(j=i+1;j<value.length;j++)
                {
                    if(value[j]=="+" || value[j]=="-" || value[j]=="*" || value[j]=="/")
                    {
                        let a1=parseInt(a);
                        let b1=parseInt(b);
                        t=t+(a1+b1);
                        a="";
                        b="";
                        console.log(t);
                        i=j;
                        break;
                    }
                    else{
                        b=b+value[j];
                    }
                }
            }
            else if(value[i]=="*")
            {
                for(j=i+1;j<value.length;j++)
                {
                    if(value[j]=="+" || value[j]=="-" || value[j]=="*" || value[j]=="/")
                    {
                        let a1=parseInt(a);
                        let b1=parseInt(b);
                        t=t+(a1+b1);
                        a="";
                        b="";
                        console.log(t);
                        i=j;
                        break;
                    }
                    else{
                        b=b+value[j];
                    }
                }
            }
            else if(value[i]=="/")
            {
                for(j=i+1;j<value.length;j++)
                {
                    if(value[j]=="+" || value[j]=="-" || value[j]=="*" || value[j]=="/")
                    {
                        let a1=parseInt(a);
                        let b1=parseInt(b);
                        t=t+(a1+b1);
                        a="";
                        b="";
                        console.log(t);
                        i=j;
                        break;
                    }
                    else{
                        b=b+value[j];
                    }
                }
            }
            else{
                a=a+value[i];
            }
        }
    }

    return(
        <div className='App-calc'>
          <div >
            {value}
          </div>
          <div>
            <button className='App-plus' onClick={opetarion1}>1</button>
            <button className='App-plus' onClick={opetarion2}>2</button>
            <button className='App-plus' onClick={opetarion3}>3</button>
            <button className='App-plus' onClick={opetarionAdd}>+</button>
          </div>
          <div>
            <button className='App-plus' onClick={opetarion4}>4</button>
            <button className='App-plus' onClick={opetarion5}>5</button>
            <button className='App-plus' onClick={opetarion6}>6</button>
            <button className='App-plus' onClick={opetarionSub}>-</button>
          </div>
          <div>
            <button className='App-plus' onClick={opetarion7}>7</button>
            <button className='App-plus' onClick={opetarion8}>8</button>
            <button className='App-plus' onClick={opetarion9}>9</button>
            <button className='App-plus' onClick={opetarionDiv}>/</button>
          </div>
          <div>
            <button className='App-zero' onClick={opetarion0}>0</button>
            <button className='App-plus' onClick={opetarionMul}>*</button>
          </div>
          <div>
            <button className='App-zero' onClick={opetarionEql}>=</button>
          </div>
        </div>
    );
}

export default Calc;