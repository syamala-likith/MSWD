import logo from '../logo.jpg';
import klu from '../klu.png';
import femail from './femail.png';
import '../App.css';

function Id() {
  return(
        <div className='App-idcard'>
            <img className='App-logo' alt='' src={logo}/>
            {/* <img className='App-logo' alt='' src={femail}/> */}
            <br/>

            <div className='App-kl'>
              <img className='App-klu' alt='' src={klu}/>
            </div>

            <h1 className='App-Header'>STUDENT</h1>
            <div className='App-color'>

              <div className='App-para'>
                <p className='App-para1'>Likith Sai Reddy</p>
                {/* <p className='App-para1'>K Sai Sowjanya</p> */}
              </div>

              <div className='App-para'>
                <p className='App-para2'>2100031023</p>
                {/* <p className='App-para2'>2100031377</p> */}
                <p className='App-para3'>CSE(H)</p>
              </div>

              <div className='App-para'>
              <p className='App-para4'>2021-2025</p>
              </div>

            </div>
        </div>   
  );
}

export default Id;
